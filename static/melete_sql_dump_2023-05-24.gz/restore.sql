--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.3
-- Dumped by pg_dump version 15.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS '';


--
-- Name: tsm_system_rows; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS tsm_system_rows WITH SCHEMA public;


--
-- Name: EXTENSION tsm_system_rows; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION tsm_system_rows IS 'TABLESAMPLE method which accepts number of rows as a limit';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Era; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Era" (
    id integer NOT NULL,
    era text NOT NULL
);


ALTER TABLE public."Era" OWNER TO postgres;

--
-- Name: Philosopher; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Philosopher" (
    id integer NOT NULL,
    name text NOT NULL
);


ALTER TABLE public."Philosopher" OWNER TO postgres;

--
-- Name: PhilosopherEra; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PhilosopherEra" (
    "philosopherId" integer NOT NULL,
    "eraId" integer NOT NULL
);


ALTER TABLE public."PhilosopherEra" OWNER TO postgres;

--
-- Name: PhilosopherSchool; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PhilosopherSchool" (
    "philosopherId" integer NOT NULL,
    "schoolId" integer NOT NULL
);


ALTER TABLE public."PhilosopherSchool" OWNER TO postgres;

--
-- Name: Quote; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Quote" (
    id integer NOT NULL,
    "authorId" integer,
    text text NOT NULL
);


ALTER TABLE public."Quote" OWNER TO postgres;

--
-- Name: QuoteEra; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."QuoteEra" (
    "quoteId" integer NOT NULL,
    "eraId" integer NOT NULL
);


ALTER TABLE public."QuoteEra" OWNER TO postgres;

--
-- Name: School; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."School" (
    id integer NOT NULL,
    name text NOT NULL
);


ALTER TABLE public."School" OWNER TO postgres;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Name: randomquote; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.randomquote AS
 SELECT q.text,
    p.name,
    e.era
   FROM (((public."Quote" q TABLESAMPLE public.system_rows (1)
     LEFT JOIN public."Philosopher" p ON ((q."authorId" = p.id)))
     LEFT JOIN public."QuoteEra" qe ON ((q.id = qe."quoteId")))
     LEFT JOIN public."Era" e ON ((qe."eraId" = e.id)));


ALTER TABLE public.randomquote OWNER TO postgres;

--
-- Data for Name: Era; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Era" (id, era) FROM stdin;
\.
COPY public."Era" (id, era) FROM '$$PATH$$/3400.dat';

--
-- Data for Name: Philosopher; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Philosopher" (id, name) FROM stdin;
\.
COPY public."Philosopher" (id, name) FROM '$$PATH$$/3398.dat';

--
-- Data for Name: PhilosopherEra; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PhilosopherEra" ("philosopherId", "eraId") FROM stdin;
\.
COPY public."PhilosopherEra" ("philosopherId", "eraId") FROM '$$PATH$$/3401.dat';

--
-- Data for Name: PhilosopherSchool; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PhilosopherSchool" ("philosopherId", "schoolId") FROM stdin;
\.
COPY public."PhilosopherSchool" ("philosopherId", "schoolId") FROM '$$PATH$$/3404.dat';

--
-- Data for Name: Quote; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Quote" (id, "authorId", text) FROM stdin;
\.
COPY public."Quote" (id, "authorId", text) FROM '$$PATH$$/3399.dat';

--
-- Data for Name: QuoteEra; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."QuoteEra" ("quoteId", "eraId") FROM stdin;
\.
COPY public."QuoteEra" ("quoteId", "eraId") FROM '$$PATH$$/3402.dat';

--
-- Data for Name: School; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."School" (id, name) FROM stdin;
\.
COPY public."School" (id, name) FROM '$$PATH$$/3403.dat';

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
\.
COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM '$$PATH$$/3397.dat';

--
-- Name: Era Era_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Era"
    ADD CONSTRAINT "Era_pkey" PRIMARY KEY (id);


--
-- Name: PhilosopherEra PhilosopherEra_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PhilosopherEra"
    ADD CONSTRAINT "PhilosopherEra_pkey" PRIMARY KEY ("philosopherId", "eraId");


--
-- Name: PhilosopherSchool PhilosopherSchool_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PhilosopherSchool"
    ADD CONSTRAINT "PhilosopherSchool_pkey" PRIMARY KEY ("philosopherId", "schoolId");


--
-- Name: Philosopher Philosopher_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Philosopher"
    ADD CONSTRAINT "Philosopher_pkey" PRIMARY KEY (id);


--
-- Name: QuoteEra QuoteEra_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."QuoteEra"
    ADD CONSTRAINT "QuoteEra_pkey" PRIMARY KEY ("quoteId", "eraId");


--
-- Name: Quote Quote_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Quote"
    ADD CONSTRAINT "Quote_pkey" PRIMARY KEY (id);


--
-- Name: School School_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."School"
    ADD CONSTRAINT "School_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: PhilosopherEra PhilosopherEra_eraId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PhilosopherEra"
    ADD CONSTRAINT "PhilosopherEra_eraId_fkey" FOREIGN KEY ("eraId") REFERENCES public."Era"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PhilosopherEra PhilosopherEra_philosopherId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PhilosopherEra"
    ADD CONSTRAINT "PhilosopherEra_philosopherId_fkey" FOREIGN KEY ("philosopherId") REFERENCES public."Philosopher"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PhilosopherSchool PhilosopherSchool_philosopherId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PhilosopherSchool"
    ADD CONSTRAINT "PhilosopherSchool_philosopherId_fkey" FOREIGN KEY ("philosopherId") REFERENCES public."Philosopher"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PhilosopherSchool PhilosopherSchool_schoolId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PhilosopherSchool"
    ADD CONSTRAINT "PhilosopherSchool_schoolId_fkey" FOREIGN KEY ("schoolId") REFERENCES public."School"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: QuoteEra QuoteEra_eraId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."QuoteEra"
    ADD CONSTRAINT "QuoteEra_eraId_fkey" FOREIGN KEY ("eraId") REFERENCES public."Era"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: QuoteEra QuoteEra_quoteId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."QuoteEra"
    ADD CONSTRAINT "QuoteEra_quoteId_fkey" FOREIGN KEY ("quoteId") REFERENCES public."Quote"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Quote Quote_authorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Quote"
    ADD CONSTRAINT "Quote_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES public."Philosopher"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

